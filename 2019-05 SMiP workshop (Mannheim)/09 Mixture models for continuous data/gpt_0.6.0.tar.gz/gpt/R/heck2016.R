#' Recognition Memory Data of a Single Participant
#'
#' A dataset containing 'old' and 'new' responses of a single participant from a 2x2 within design (memory strength: strong vs. weak; base rate: 30% vs. 70% old items). Besides the categorical responses, the data set contains response times. 
#'
#' @format A data frame with 1,200 rows and 2 variables:
#' \describe{
#'   \item{cat}{type of response}
#'   \item{rt}{response time}
#' }
#' @examples 
#' \dontrun{
#' head(heck2016)
#' file <- paste0(path.package("gpt"), "/models/2htm_exgauss_2x2.txt")
#' fit <- gpt_fit("cat", "rt", heck2016, file=file,
#'                latent="exgauss", n.fit=c(1,1),
#'                restrictions=list("dn_s=do_s", "dn_w=do_w"))
#' fit
#' pqplot(fit)
#' hist(fit)
#' plot(fit)
#' }
"heck2016"